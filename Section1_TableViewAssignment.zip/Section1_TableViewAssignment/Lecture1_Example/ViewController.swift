//
//  ViewController.swift
//  Lecture1_Example
//
//  Created by Rolan on 7/15/22.
//

import UIKit

class ViewController: UIViewController {
    
    private var country: [String] = ["India", "China", "United States", "Indonesia", "Pakistan", "Nigeria", "Brazil", "Bangladesh", "Russia", "Mexico", "Ethiopia", "japan", "Philippines", "Egypt", "Dr Congo", "Vietnam", "Iran", "Turkey", "Germany", "Thailand", "United Kingdom", "Tanzania", "France", "South Africa", "Italy", "Kenya", "Myanmar", "Colombia", "South Korea", "Uganda" ]
    
    private var countryPopulation = ["1,422,131,557", "1,425,846,796", "339,094,501", "276,405,380", "238,164,520", "221,196,265", "215,812,275", "172,089,522", "144,689,669", "127,991,341", "124,962,044", "123,619,005", "116,466,364", "111,861,120", "100,632,588", "98,536,011", "88,849,828", "85,594,179", "83,313,264", "71,754,701", "67,625,016", "66,472,399", "64,694,481", "60,145,898", "58,954,601", "54,563,393", "54,383,925", "51,960,962", "51,802,690", "47,925,594"]
    
    @IBOutlet var countryTableView: UITableView!
    
    private let cellIdentifier = "CellIdentifier"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        countryTableView.register(UITableViewCell.self,
                               forCellReuseIdentifier: cellIdentifier)
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return country.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier,
                                                 for: indexPath)
        let country = country[indexPath.row]
        let countryPopulation = countryPopulation[indexPath.row]
        
        var configuration = cell.defaultContentConfiguration()
        
        configuration.text = country
        configuration.secondaryText = countryPopulation
        
        cell.contentConfiguration = configuration
        
        return cell
    }
}
