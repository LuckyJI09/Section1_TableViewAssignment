//
//  Model.swift
//  Lecture1_Example
//
//  Created by Rolan on 7/16/22.
//

import Foundation

class Model {
    var title: String
    var name: String
    
    init(title: String,
         name: String) {
        self.title = title
        self.name = name
    }
}
